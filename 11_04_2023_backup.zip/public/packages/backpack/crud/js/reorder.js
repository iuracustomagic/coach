/*
*
* Backpack Crud / Reorder
*
*/

jQuery(function($){

    'use strict';
});
