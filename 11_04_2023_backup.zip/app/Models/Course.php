<?php

namespace App\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use CrudTrait;

    /*
    |--------------------------------------------------------------------------
    | GLOBAL VARIABLES
    |--------------------------------------------------------------------------
    */

    protected $table = 'courses';
    // protected $primaryKey = 'id';
    // public $timestamps = false;
    protected $guarded = ['id'];
    // protected $fillable = [];
    // protected $hidden = [];
    // protected $dates = [];

    /*
    |--------------------------------------------------------------------------
    | FUNCTIONS
    |--------------------------------------------------------------------------
    */

    public static function isAvailable($course_id)
    {
        $pivot = \App\Models\UserAvailableCourses::where(['user_id' => backpack_user()->id, 'course_id' => $course_id])->first();
        return !empty($pivot);
    }

    public static function finalQuiz($course_id)
    {
        return \App\Models\Quiz::where(['course_id' => $course_id, 'is_final' => 1])->first();
    }

    /*
    |--------------------------------------------------------------------------
    | RELATIONS
    |--------------------------------------------------------------------------
    */

    public function companies()
    {
        return $this->belongsToMany('App\Models\Company','course_companies')->using(\App\Models\CourseCompanies::class);
    }

    public function divisions()
    {
        return $this->belongsToMany('App\Models\Division','course_divisions')->using(\App\Models\CourseDivisions::class);
    }

    public function lessons()
    {
        return $this->hasMany('App\Models\Lesson', 'course_id', 'id')->orderBy('lessons.sort_order','ASC');
    }

    public function profession()
    {
        return $this->belongsTo('App\Models\Profession', 'profession_id', 'id');
    }

    /*
    |--------------------------------------------------------------------------
    | SCOPES
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | ACCESSORS
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | MUTATORS
    |--------------------------------------------------------------------------
    */

    public function setSortOrderAttribute($value)
    {
        if(null == $value){
            $courses = self::all()->count();
            $this->attributes['sort_order'] = $courses + 1;
        } else {
            if($value < 1){
                $value = 1;
            }
            $this->attributes['sort_order'] = $value;
        }
    }
}
