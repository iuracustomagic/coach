<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Branch;
use App\Models\User;

class ReportsController extends Controller
{
    public function branch($branch_id){
        $branch = Branch::find($branch_id);
        $hierarchy = $this->buildHierarchy($branch->activeEmployees);
        $rows = $this->drawRows($hierarchy);
        return view('reports/branch', [
            'rows' => $rows
        ]);
    }

    protected function buildHierarchy($employees, $supervisor = null)
    {
        $hierarchy = array();
        foreach($employees as $employee){
            if($supervisor == $employee->supervisor_id){
                $hierarchy[$employee->id] = [
                    'id' => $employee->id,
                    'supervisor' => $employee->supervisor ? $employee->supervisor->name : '-',
                    'name' => $employee->name,
                    'proffession' => $employee->profession ? $employee->profession->name : '-',
                    'has_subordinates' => $employee->subordinates->count() > 0 ? true : false,
                    'subordinates' => $employee->subordinates->count() > 0 ? $this->buildHierarchy($employee->subordinates, $employee->id) : null,
                    'registered' => date('Y-m-d',strtotime($employee->created_at)),
                    'theory_available' => $employee->totalAvailable,
                    'theory_passed' => $employee->totalPassed,
                    'theory_avg'  => $employee->avg_total,
                    'last_mark' => $employee->getLastEvaluation ? $employee->getLastEvaluation->mark : '-',
                    'subordinates_avg' => $employee->getSubordinatesAvg(),
                    'final_grade' => $employee->getFinalGrade()
                ];
            }
        }
        return $hierarchy;
    }

    protected function drawRows($hierarchy, $lvl = 0, $index = 1)
    {
        $rows = array();
        
        foreach($hierarchy as $id => $employee){
            for($i = 0; $i < $lvl; $i++){
                $own = $i+1 == $lvl ? "<span class='own o-lvl-".$lvl."'></span>" : "";
            }
            $marker = "";
            if($employee['final_grade'] < 7.5){
                $marker = "class='table-warning'";
            }
            if($employee['final_grade'] < 6.5){
                $marker = "class='table-danger'";
            }
            $toggler = "<span class='toggler t-lvl-".$lvl." toggle-subordinates' data-subordinates-to='" . $id . "'>+</span>";
            $row = "<tr ".$marker.">";
            $row .= "<td class='controls'>";
                $row .= $employee['has_subordinates'] ? $toggler : '';
                $row .= $own ?? "";
            $row .= "</td>";
            $row .= "<td class='index'>";
                $row .= $index;
            $row .= "</td>";
            $row .= "<td class='prof'>";
                $row .= $employee['proffession'];
            $row .= "</td>";
            $row .= "<td class='employee'>";
                $row .= $employee['name'];
            $row .="</td>";
            $row .= "<td class='date'>";
                $row .= $employee['registered'];
            $row .="</td>";
            $row .= "<td class='available'>";
                $row .= $employee['theory_available'];
            $row .="</td>";
            $row .= "<td class='passed'>";
                $row .= $employee['theory_passed'];
            $row .="</td>";
            $row .= "<td class='avg'>";
                $row .= $employee['theory_avg'];
            $row .="</td>";
            $row .= "<td class='ev-list'>";                
                $row .= $employee['last_mark'];
                $row .= " <button class='btn btn-primary btn-sm show-evaluations' data-employee-id='".$employee['id']."'><i class='las la-eye'></i></button>";
            $row .="</td>";   
            $row .= "<td class='avg'>";  
                $row .= $employee['subordinates_avg'];
            $row .="</td>";              
            $row .= "<td class='res'>";  
                $row .= $employee['final_grade'];
            $row .="</td>";  
            $row .= "<td class='supervisor'>";  
                $row .= $employee['supervisor'];
            $row .="</td>";   

            $row .= "</tr>";
            
            $rows[] = $row; 

            if($employee['has_subordinates']){
                $subordinates = $this->drawRows($employee['subordinates'], $lvl + 1,  $index + 1);
                $rows[] = "<tr class='may-hide hidden' data-supervisor='" . $employee['id'] . "'><td colspan='12'><table class='lvl lvl-".$lvl."'>";
                foreach($subordinates as $subordinate){
                    $rows[] = $subordinate;
                }
                $rows[] = "</table></td></tr>";
                $index += count($subordinates) + 1;
            } else {
                $index++;
            }
        }

        return $rows;
    }

    public function viewEvaluations($employee_id){
        $employee = User::find($employee_id);
        if($employee->monthsEvaluations){
            foreach($employee->monthsEvaluations as $evaluation){
                $evaluations[] = [
                    'date' => $evaluation->created_at,
                    'examiner' => $evaluation->examiner ? $evaluation->examiner->name : '-',
                    'mark' => $evaluation->mark
                ];
            }
        }
        if(!empty($evaluations)){
            $table = "<table class='table table-stripped'>";
                $table .= "<tr>";
                    $table .= "<th>Дата</th>";
                    foreach($evaluations as $evaluation){
                        $table .= "<td>";
                            $table .= date('Y-m-d',strtotime($evaluation['date']));
                        $table .= "</td>";
                    }
                    $table .= "</tr>";
                    $table .= "<tr>";
                    $table .= "<th>Оценивал</th>";
                    foreach($evaluations as $evaluation){
                        $table .= "<td>";
                            $table .= $evaluation['examiner'];
                        $table .= "</td>";
                    }
                    $table .= "</tr>";
                    $table .= "<tr>";
                    $table .= "<th>Оценка</th>";
                    foreach($evaluations as $evaluation){
                        $table .= "<td>";
                            $table .= $evaluation['mark'];
                        $table .= "</td>";
                    }
                $table .= "</tr>";
            $table .= "</table>";
        } else {
            $table = "Нет доступных оценочных листов";
        }
        return [
            'employee' => $employee->name,
            'evaluations' => $table
        ];
    }
}