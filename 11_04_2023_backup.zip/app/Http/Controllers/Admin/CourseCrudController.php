<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\CourseRequest;
use Backpack\CRUD\app\Http\Controllers\CrudController;
use Backpack\CRUD\app\Library\CrudPanel\CrudPanelFacade as CRUD;

/**
 * Class CourseCrudController
 * @package App\Http\Controllers\Admin
 * @property-read \Backpack\CRUD\app\Library\CrudPanel\CrudPanel $crud
 */
class CourseCrudController extends CrudController
{
    use \Backpack\CRUD\app\Http\Controllers\Operations\ListOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\CreateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\UpdateOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\DeleteOperation;
    use \Backpack\CRUD\app\Http\Controllers\Operations\ShowOperation;

    /**
     * Configure the CrudPanel object. Apply settings to all operations.
     * 
     * @return void
     */
    public function setup()
    {
        CRUD::setModel(\App\Models\Course::class);
        CRUD::setRoute(config('backpack.base.route_prefix') . '/course');
        CRUD::setEntityNameStrings(trans('nav.course'), trans('nav.courses'));
    }

    /**
     * Define what happens when the List operation is loaded.
     * 
     * @see  https://backpackforlaravel.com/docs/crud-operation-list-entries
     * @return void
     */
    protected function setupListOperation()
    {
        $this->crud->enableDetailsRow();

        /* Get only courses from admins or managers division */
        if(backpack_user()->hasRole('Admin') || backpack_user()->hasRole('Manager')){

            $this->crud->denyAccess('delete');

            if(backpack_user()->hasRole('Manager')){
                $this->crud->denyAccess('update');
            }

            $courses = [];
            if(!empty(backpack_user()->divisions)){
                foreach(backpack_user()->divisions as $division){
                    if(!empty($division->courses)){
                        foreach($division->courses as $course){
                            $courses[] = $course->id;
                        }
                    }
                }
            }

            $this->crud->addClause('whereIn', 'id', $courses);
        }

        //CRUD::column('id');
        CRUD::column('name')->limit(100);
        CRUD::column('description');
        CRUD::column('profession_id');
        CRUD::column('banner');
        CRUD::column('sort_order');
        //CRUD::column('created_at');
        //CRUD::column('updated_at');

        /**
         * Columns can be defined using the fluent syntax or array syntax:
         * - CRUD::column('price')->type('number');
         * - CRUD::addColumn(['name' => 'price', 'type' => 'number']); 
         */
    }

    /**
     * Define what happens when the Create operation is loaded.
     * 
     * @see https://backpackforlaravel.com/docs/crud-operation-create
     * @return void
     */
    protected function setupCreateOperation()
    {
        CRUD::setValidation(CourseRequest::class);

        CRUD::field('name')->label(trans('labels.name'));

        CRUD::addField([   // Textarea
            'name'  => 'description',
            'label' => trans('labels.description'),
            'type'  => 'textarea'
        ]);

        CRUD::addField([   // 1-n relationship
            'label'       => trans('labels.company'), // Table column heading
            'type'        => "select2_from_ajax_multiple",
            'name'        => 'companies', // the column that contains the ID of that connected entity
            'entity'      => 'companies', // the method that defines the relationship in your Model
            'attribute'   => "name", // foreign key attribute that is shown to user
            'data_source' => url("api/company"), // url to controller search function (with /{id} should return model)

            // OPTIONAL
            'delay' => 500, // the minimum amount of time between ajax requests when searching in the field
            'placeholder'             => trans('labels.select_company'), // placeholder for the select
            'minimum_input_length'    => 0, // minimum characters to type before querying results
            'model'                   => "App\Models\Company", // foreign key model
            // 'method'                  => 'GET', // optional - HTTP method to use for the AJAX call (GET, POST)
            //'include_all_form_fields' => true, // optional - only send the current field through AJAX (for a smaller payload if you're not using multiple chained select2s)
            'wrapper'   => [
               'class' => 'form-group col-md-4'
            ]
        ]);

        CRUD::addField([   // 1-n relationship
            'label'       => trans('labels.division'), // Table column heading
            'type'        => "select2_from_ajax_multiple",
            'name'        => 'divisions', // the column that contains the ID of that connected entity
            'entity'      => 'divisions', // the method that defines the relationship in your Model
            'attribute'   => "name", // foreign key attribute that is shown to user
            'data_source' => url("api/division"), // url to controller search function (with /{id} should return model)

            // OPTIONAL
            'delay' => 500, // the minimum amount of time between ajax requests when searching in the field
            'placeholder'             => trans('labels.select_division'), // placeholder for the select
            'minimum_input_length'    => 0, // minimum characters to type before querying results
            'model'                   => "App\Models\Division", // foreign key model
            'dependencies'            => ['company_id'], // when a dependency changes, this select2 is reset to null
            // 'method'                  => 'GET', // optional - HTTP method to use for the AJAX call (GET, POST)
            'include_all_form_fields' => true, // optional - only send the current field through AJAX (for a smaller payload if you're not using multiple chained select2s)
            'wrapper'   => [
               'class' => 'form-group col-md-4'
            ]
        ]);

        CRUD::field('profession_id')->label(trans('labels.profession'))->wrapper(['class' => 'form-group col-md-4']);

        CRUD::addField([   // Number
            'name' => 'sort_order',
            'label' => trans('labels.sort_order'),
            'type' => 'number',
            // optionals
            'attributes' => ["step" => "1", "min" => "1"], // allow decimals
        ]);

        CRUD::addField([   // Browse
            'name'  => 'banner',
            'label' => trans('labels.banner'),
            'type'  => 'browse'
        ]);

        /**
         * Fields can be defined using the fluent syntax or array syntax:
         * - CRUD::field('price')->type('number');
         * - CRUD::addField(['name' => 'price', 'type' => 'number'])); 
         */
    }

    /**
     * Define what happens when the Update operation is loaded.
     * 
     * @see https://backpackforlaravel.com/docs/crud-operation-update
     * @return void
     */
    protected function setupUpdateOperation()
    {
        $this->setupCreateOperation();
    }

    protected function showDetailsRow($id)
    {
        $course = \App\Models\Course::find($id);
        if(!empty($course) && !empty($course->lessons)){
            $markup = "<table>";
            $markup .= "<tr><th>Lesson</th></tr>";
            
            foreach($course->lessons as $lesson){
                $markup .= "<tr><td>" . $lesson->name . "</td></tr>";
            }
                
            $markup .= "</table>";
            return $markup;
        } else {
            return "Нет доступных данных";
        }
    }
}
